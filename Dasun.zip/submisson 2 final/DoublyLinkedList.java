public class DoublyLinkedListWithReverse {

    class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    Node head;
    Node tail;

    public void insertAtBeginning(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        System.out.println(data + " inserted");
    }

    public void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        System.out.println(data + " inserted");
    }

    public void insertAfter(int target, int data) {
        Node current = head;
        while (current != null && current.data != target) {
            current = current.next;
        }
        if (current == null) {
            System.out.println("Target not found");
            return;
        }
        Node newNode = new Node(data);
        newNode.next = current.next;
        newNode.prev = current;
        if (current.next != null) current.next.prev = newNode;
        else tail = newNode;
        current.next = newNode;
        System.out.println(data + " inserted after " + target);
    }

    public boolean search(int data) {
        Node current = head;
        while (current != null) {
            if (current.data == data) return true;
            current = current.next;
        }
        return false;
    }

    public void delete(int data) {
        Node current = head;
        while (current != null && current.data != data) current = current.next;
        if (current == null) {
            System.out.println("Value not found");
            return;
        }
        if (current.prev != null) current.prev.next = current.next;
        else head = current.next;
        if (current.next != null) current.next.prev = current.prev;
        else tail = current.prev;
        System.out.println(data + " deleted");
    }

    public void reverse() {
        Node current = head;
        Node temp = null;
        while (current != null) {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        }
        temp = head;
        head = tail;
        tail = temp;
        System.out.println("List reversed");
    }

    public void displayForward() {
        if (head == null) { System.out.println("List is empty"); return; }
        System.out.print("Forward: ");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " <-> ");
            current = current.next;
        }
        System.out.println("null");
    }

    public void displayBackward() {
        if (tail == null) { System.out.println("List is empty"); return; }
        System.out.print("Backward: ");
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + " <-> ");
            current = current.prev;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        DoublyLinkedListWithReverse list = new DoublyLinkedListWithReverse();

        list.insertAtBeginning(20);
        list.insertAtBeginning(10);
        list.insertAtEnd(30);
        list.insertAtEnd(40);

        list.insertAfter(20, 25);
        list.displayForward();

        System.out.println("Search 30: " + list.search(30));
        System.out.println("Search 99: " + list.search(99));

        list.reverse();
        list.displayForward();
        list.displayBackward();

        list.delete(25);
        list.displayForward();
    }
}