public class SinglyLinkedListWithReverse {

    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head;

    public void insertAtBeginning(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
        System.out.println(data + " inserted");
    }

    public void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) { head = newNode; return; }
        Node current = head;
        while (current.next != null) current = current.next;
        current.next = newNode;
        System.out.println(data + " inserted");
    }

    public void insertAtPosition(int position, int data) {
        if (position < 0) { System.out.println("Invalid position"); return; }
        if (position == 0) { insertAtBeginning(data); return; }

        Node newNode = new Node(data);
        Node current = head;
        for (int i = 0; i < position - 1 && current != null; i++) {
            current = current.next;
        }
        if (current == null) { System.out.println("Position out of bounds"); return; }
        newNode.next = current.next;
        current.next = newNode;
        System.out.println(data + " inserted at position " + position);
    }

    public void delete(int data) {
        if (head == null) { System.out.println("List is empty"); return; }
        if (head.data == data) {
            head = head.next;
            System.out.println(data + " deleted");
            return;
        }
        Node current = head;
        while (current.next != null && current.next.data != data) current = current.next;
        if (current.next == null) { System.out.println("Value not found"); return; }
        current.next = current.next.next;
        System.out.println(data + " deleted");
    }

    public boolean search(int data) {
        Node current = head;
        while (current != null) {
            if (current.data == data) return true;
            current = current.next;
        }
        return false;
    }

    public int length() {
        int count = 0;
        Node current = head;
        while (current != null) { count++; current = current.next; }
        return count;
    }

    public void reverse() {
        Node prev = null, current = head, next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
        System.out.println("List reversed");
    }

    public void display() {
        if (head == null) { System.out.println("List is empty"); return; }
        System.out.print("List: ");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        SinglyLinkedListWithReverse list = new SinglyLinkedListWithReverse();

        list.insertAtBeginning(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        list.insertAtBeginning(5);

        list.insertAtPosition(2, 15);
        list.display();

        System.out.println("Length: " + list.length());
        System.out.println("Search 15: " + list.search(15));
        System.out.println("Search 99: " + list.search(99));

        list.reverse();
        list.display();

        list.delete(15);
        list.display();
    }
}